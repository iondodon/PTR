defmodule JSON.Parser.Record.Chunk do
  @moduledoc false
  defstruct chunk: "", chunk_id: 0
end
